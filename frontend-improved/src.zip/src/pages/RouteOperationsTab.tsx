import { useState } from "react";
import { Loader2, Route, AlertTriangle, CheckCircle, ArrowRight, Info } from "lucide-react";
import CitySearch from "@/components/CitySearch";
import LeafletMap from "@/components/LeafletMap";
import { RouteData, useAppContext } from "@/contexts/AppContext";
import { fetchRoute } from "@/lib/api";
import { toast } from "sonner";

export default function RouteOperationsTab() {
  const { state, dispatch, addLog } = useAppContext();
  const [finding, setFinding] = useState(false);


function distancePointToSegment(p1Lat: number, p1Lon: number, p2Lat: number, p2Lon: number, cLat: number, cLon: number): number {
  // Approximate closest distance from point C to line segment P1-P2 using equirectangular projection
  const A = p1Lat - cLat;
  const B = p1Lon - cLon;
  const C = p2Lat - cLat;
  const D = p2Lon - cLon;

  const dot = A * C + B * D;
  const lenSq = C * C + D * D;
  let param = -1;
  if (lenSq !== 0) param = dot / lenSq;

  let xx, yy;
  if (param < 0) {
    xx = p1Lon;
    yy = p1Lat;
  } else if (param > 1) {
    xx = p2Lon;
    yy = p2Lat;
  } else {
    xx = p1Lon + param * (p2Lon - p1Lon);
    yy = p1Lat + param * (p2Lat - p1Lat);
  }

  return haversineCheck(yy, xx, cLat, cLon);
}

function hasPathDisasterIntersection(route: RouteData, disasters: any[]): boolean {
  for (let i = 0; i < route.path.length - 1; i++) {
    const p1 = route.path[i];
    const p2 = route.path[i + 1];

    for (const d of disasters) {
      const minDist = distancePointToSegment(
        p1.lat, p1.lon,
        p2.lat, p2.lon,
        d.location.lat, d.location.lon
      );
      if (minDist <= d.radius + 2) { // SAFETY BUFFER +2km
        return true;
      }
    }
  }
  return false;
}

const handleFindRoute = async () => {
  if (!state.source || !state.destination) {
    toast.error("Please select both source and destination cities.");
    return;
  }
  if (
    state.source.lat === state.destination.lat &&
    state.source.lon === state.destination.lon
  ) {
    toast.error("Source and destination cannot be the same city.");
    return;
  }

  setFinding(true);
  dispatch({ type: "SET_LOADING", payload: { route: true } });
  dispatch({ type: "SET_ERROR", payload: { route: null } });
  dispatch({ type: "SET_ROUTE", payload: null });
  dispatch({ type: "SET_ALTERNATE_ROUTE", payload: null });

  try {
    // Fetch primary route
    const primaryRoute = await fetchRoute(state.source, state.destination, true);
    const altRoute = null;
    const activeDisasters = state.disasters.filter(d => d.status === "active");

function isRouteActuallySafe(path, disasters) {
  for (let i = 0; i < path.length - 1; i++) {
    const p1 = path[i];
    const p2 = path[i + 1];

    for (const d of disasters) {
      const dist = distancePointToSegment(
        d.location.lat,
        d.location.lon,
        p1.lat,
        p1.lon,
        p2.lat,
        p2.lon
      );

      if (dist <= d.radius) {
        return false; // ❌ intersects disaster
      }
    }
  }
  return true;
}

const isSafe = isRouteActuallySafe(primaryRoute.path, activeDisasters);
    const pathBlocked = hasPathDisasterIntersection(primaryRoute, activeDisasters);
    const isBlocked = primaryRoute.blocked || pathBlocked;
    if (isBlocked) {
      const blockedRoute = {
        ...primaryRoute,
        blocked: isBlocked,
        safe: isSafe,
        alternateAvailable: true,
      };
      dispatch({ type: "SET_ROUTE", payload: blockedRoute });
      addLog(
        "route",
        `Route blocked by active disaster zone (backend or frontend detection)`,
        "warning"
      );
      toast.warning("Primary route affected by disaster zone. Alternate route loaded.");

      if (altRoute.status === "fulfilled") {
        dispatch({ type: "SET_ALTERNATE_ROUTE", payload: altRoute.value });
        addLog(
          "route",
          `Alternate safe route: ${altRoute.value.distance} km, ETA: ${altRoute.value.eta}`,
          "success"
        );
      } else {
        addLog("route", "No alternate route available.", "error");
        toast.error("No alternate route could be calculated.");
      }
    } else {
      dispatch({ type: "SET_ROUTE", payload: primaryRoute });
      addLog(
        "route",
        `Safe route confirmed: ${primaryRoute.distance} km, ETA: ${primaryRoute.eta}`,
        "success"
      );
      toast.success(`Safe route: ${primaryRoute.distance} km, ETA: ${primaryRoute.eta}`);

      // Show alternate if available
      if (altRoute.status === "fulfilled") {
        dispatch({ type: "SET_ALTERNATE_ROUTE", payload: altRoute.value });
      }
    }
  } catch (err: any) {
    const msg = err.message ?? "Unknown error";
    addLog("route", `Route calculation failed: ${msg}`, "error");
    dispatch({ type: "SET_ERROR", payload: { route: msg } });
    toast.error("Failed to calculate route.");
  } finally {
    setFinding(false);
    dispatch({ type: "SET_LOADING", payload: { route: false } });
  }
};

  const handleClearRoute = () => {
    dispatch({ type: "SET_SOURCE", payload: null });
    dispatch({ type: "SET_DESTINATION", payload: null });
    dispatch({ type: "SET_ROUTE", payload: null });
    dispatch({ type: "SET_ALTERNATE_ROUTE", payload: null });
    addLog("route", "Route cleared.", "info");
  };

  // Add this helper function inside the component file (outside the component):
  function haversineCheck(
    lat1: number, lon1: number,
    lat2: number, lon2: number
  ): number {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  const activeDisasters = state.disasters.filter((d) => d.status === "active");
  const routeLogs = state.logs.filter((l) => l.type === "route").slice(0, 8);

  
function RouteInfoCard({
  label, route, blocked, isAlternate,
}: {
  label: string; route: any; blocked: boolean; isAlternate?: boolean;
}) {
  return (
    <div className={`rounded-xl border-2 p-4 ${
      blocked
        ? "border-red-300 bg-red-50"
        : isAlternate
        ? "border-emerald-400 bg-emerald-50"
        : "border-emerald-200 bg-emerald-50"
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          {blocked
            ? <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
            : <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />}
          <span className="text-sm font-bold text-foreground">{label}</span>
        </div>
        {blocked ? (
          <span className="text-[10px] font-bold uppercase tracking-wide text-red-700 bg-red-100 px-2 py-1 rounded-md border border-red-200">
            BLOCKED ✕
          </span>
        ) : isAlternate ? (
          <span className="text-[10px] font-bold uppercase tracking-wide text-emerald-700 bg-emerald-100 px-2 py-1 rounded-md border border-emerald-200">
            RECOMMENDED ✓
          </span>
        ) : null}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="text-center bg-white/60 rounded-lg py-2 px-1">
          <p className={`text-lg font-bold ${blocked ? "text-red-600" : "text-emerald-700"}`}>
            {route.distance} km
          </p>
          <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground mt-0.5">
            Distance
          </p>
        </div>
        <div className="text-center bg-white/60 rounded-lg py-2 px-1">
          <p className={`text-lg font-bold ${blocked ? "text-red-600" : "text-emerald-700"}`}>
            {route.eta}
          </p>
          <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground mt-0.5">
            ETA
          </p>
        </div>
        <div className="text-center bg-white/60 rounded-lg py-2 px-1">
          <p className={`text-lg font-bold ${blocked ? "text-red-600" : "text-emerald-700"}`}>
            {blocked ? "Blocked" : "Safe"}
          </p>
          <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground mt-0.5">
            Status
          </p>
        </div>
      </div>

      {/* Warning / recommendation message */}
      {blocked && (
        <div className="mt-3 flex items-center gap-2 rounded-lg bg-red-100 border border-red-200 px-3 py-2 text-xs text-red-700 font-medium">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          Passes through active disaster zone — use alternate route
        </div>
      )}
      {isAlternate && (
        <div className="mt-3 flex items-center gap-2 rounded-lg bg-emerald-100 border border-emerald-200 px-3 py-2 text-xs text-emerald-700 font-medium">
          <CheckCircle className="h-3.5 w-3.5 shrink-0" />
          System recommends using the alternate route for safe delivery
        </div>
      )}
    </div>
  );
}  return (
    <div className="flex h-[calc(100vh-112px)] overflow-hidden">
  
  <div className="w-[65%] min-w-0 p-3">
    <LeafletMap className="h-full w-full" />
  </div>

  <div className="w-[35%] shrink-0 overflow-y-auto border-l bg-white p-6 space-y-6">
    
    {/* Route Planning */}
        <section className="space-y-4">
          <h3 className="section-title">Route Planning</h3>
          <div className="space-y-3">
            <CitySearch label="Source City" value={state.source}
              onSelect={(c) => { dispatch({ type: "SET_SOURCE", payload: c }); dispatch({ type: "SET_ROUTE", payload: null }); dispatch({ type: "SET_ALTERNATE_ROUTE", payload: null }); }}
              placeholder="Search source city..." />
            <CitySearch label="Destination City" value={state.destination}
              onSelect={(c) => { dispatch({ type: "SET_DESTINATION", payload: c }); dispatch({ type: "SET_ROUTE", payload: null }); dispatch({ type: "SET_ALTERNATE_ROUTE", payload: null }); }}
              placeholder="Search destination city..." />

            {state.source && state.destination && (
              <div className="flex items-center gap-2 rounded-lg bg-muted px-3 py-2.5 text-sm">
                <span className="font-semibold text-foreground truncate">{state.source.name}</span>
                <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="font-semibold text-foreground truncate">{state.destination.name}</span>
              </div>
            )}

            <div className="flex gap-2">
              <button onClick={handleFindRoute}
                disabled={finding || !state.source || !state.destination}
                className="btn-primary flex-1">
                {finding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Route className="h-4 w-4" />}
                {finding ? "Calculating..." : "Find Route"}
              </button>
              {(state.source || state.destination || state.route) && (
                <button onClick={handleClearRoute} disabled={finding} className="btn-outline px-3">
                  Clear
                </button>
              )}
            </div>

            {state.errors.route && (
              <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-xs text-red-700">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {state.errors.route}
              </div>
            )}
          </div>
        </section>

{/* Route Result */}
{state.route && (
  <section className="space-y-3">
    <h3 className="section-title">Route Result</h3>

    {/* PRIMARY ROUTE */}
    <RouteInfoCard
      label="Primary Route (Original)"
      route={state.route}
      blocked={state.route.blocked}
    />

    {/* ALTERNATE ROUTE */}
    {state.alternateRoute && (
      <>
        <RouteInfoCard
          label="Alternate Route (Recommended)"
          route={state.alternateRoute}
          blocked={state.alternateRoute.blocked}
          isAlternate
        />

        {/* Recommendation Logic */}
        {!state.alternateRoute.blocked && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700 font-medium">
            ✔ System recommends using the alternate route for safe delivery
          </div>
        )}

        {state.alternateRoute.blocked && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
            ⚠ Alternate route is also affected. Manual decision required.
          </div>
        )}
      </>
    )}

    {/* NO ALTERNATE CASE */}
    {state.route.blocked && !state.alternateRoute && (
      <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs text-amber-800">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        No alternate route available. Manual coordination required.
      </div>
    )}
  </section>
)}
      </div>
    </div>
  );
}
